"""Database compatibility helpers for SQLite and PostgreSQL.

本项目原先完全基于 SQLite。为支持多站点、多模块并发管理，这里补一层
轻量数据库适配，尽量保持现有 SQL 写法不大改：

1. 默认仍兼容本地 SQLite 文件，方便开发和离线调试。
2. 当传入 PostgreSQL DSN，或环境变量 DATABASE_URL 存在时，自动切到 PostgreSQL。
3. 对 PostgreSQL 自动把 qmark 风格参数 `?` 转成 `%s`，减少现有业务 SQL 的改动量。
4. 提供表存在、列清单、表清单等跨数据库的元数据查询能力，替代 sqlite_master/PRAGMA。
"""

from __future__ import annotations

import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

import psycopg
from psycopg.pq import TransactionStatus
from psycopg.rows import dict_row

POSTGRES_SCHEMES = ("postgres://", "postgresql://")
DEFAULT_POSTGRES_DSN = os.getenv("DATABASE_URL", "").strip()
POSTGRES_REQUIRED_ERROR = (
    "未配置 PostgreSQL 数据库连接。"
    "请设置 DATABASE_URL 环境变量或通过 --db-path 参数传入。"
)
DEFAULT_POSTGRES_POOL_MAX_SIZE = 20
DEFAULT_POSTGRES_POOL_TIMEOUT = 10.0


def _env_int(name: str, default: int, *, minimum: int = 1) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return max(minimum, value)


def _env_float(name: str, default: float, *, minimum: float = 0.1) -> float:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return max(minimum, value)


def is_postgres_target(target: str | Path | None) -> bool:
    """判断目标是否为 PostgreSQL DSN。"""
    if target is None:
        return False
    return str(target).strip().lower().startswith(POSTGRES_SCHEMES)


def default_postgres_target() -> str:
    """Return the PostgreSQL target used by formal runtime code.

    正式运行数据库统一使用 PostgreSQL；不再回退到
    `backend/data/lottery_modes.sqlite3`，避免误创建空 SQLite 文件。
    """
    env_target = os.getenv("DATABASE_URL", "").strip()
    if env_target:
        return env_target
    if DEFAULT_POSTGRES_DSN:
        return DEFAULT_POSTGRES_DSN
    raise RuntimeError(POSTGRES_REQUIRED_ERROR)


def resolve_database_target(target: str | Path | None = None) -> str:
    """统一解析数据库目标。

    正式运行默认只解析 PostgreSQL 目标。只有显式传入非 PostgreSQL 路径时，
    才把它当作 SQLite 目标，用于历史迁移或显式测试。
    """
    if is_postgres_target(target):
        return str(target).strip()

    if target is None:
        return default_postgres_target()

    return str(Path(target))


def detect_database_engine(target: str | Path | None = None) -> str:
    """返回 `sqlite` 或 `postgres`。"""
    return "postgres" if is_postgres_target(resolve_database_target(target)) else "sqlite"


def quote_identifier(identifier: str) -> str:
    """安全引用表名/列名。
    arg:
    - identifier: 表名或列名字符串，例如 lottery_draws、next_time 等。
    returns:
    - quoted: 安全引用后的字符串，例如 "lottery_draws"、"next_time" 等，内部的双引号会被转义为 ""。
    """
    return '"' + str(identifier).replace('"', '""') + '"'


def auto_increment_primary_key(column_name: str = "id", engine: str = "sqlite") -> str:
    """生成自增主键 SQL 片段。"""
    if engine == "postgres":
        return f"{quote_identifier(column_name)} BIGSERIAL PRIMARY KEY"
    return f"{quote_identifier(column_name)} INTEGER PRIMARY KEY AUTOINCREMENT"


def normalize_params(params: Any) -> Any:
    """把 list 等参数转换成驱动可接受的序列类型。"""
    if params is None:
        return ()
    if isinstance(params, tuple):
        return params
    if isinstance(params, list):
        return tuple(params)
    return params


def qmark_to_format(sql_text: str) -> str:
    """把 SQLite 的 `?` 占位符转换为 PostgreSQL `%s`。

    这里只做轻量语法扫描：忽略单引号、双引号中的 `?`，满足当前项目 SQL 即可。
    """
    result: list[str] = []
    in_single = False
    in_double = False
    index = 0

    while index < len(sql_text):
        char = sql_text[index]

        if char == "'" and not in_double:
            # 处理 SQL 单引号转义 ''
            if in_single and index + 1 < len(sql_text) and sql_text[index + 1] == "'":
                result.append("''")
                index += 2
                continue
            in_single = not in_single
            result.append(char)
            index += 1
            continue

        if char == '"' and not in_single:
            in_double = not in_double
            result.append(char)
            index += 1
            continue

        if char == "?" and not in_single and not in_double:
            result.append("%s")
        else:
            result.append(char)

        index += 1

    return "".join(result)


class CursorAdapter:
    """统一 sqlite3 / psycopg 游标接口。"""

    def __init__(self, cursor: Any):
        self._cursor = cursor

    @property
    def rowcount(self) -> int:
        return getattr(self._cursor, "rowcount", -1)

    def fetchone(self) -> Any:
        return self._cursor.fetchone()

    def fetchall(self) -> list[Any]:
        return self._cursor.fetchall()


class _PooledPostgresConnectionManager:
    """Small thread-safe pool for psycopg connections.

    The project uses `with connect(...) as conn` widely. Pooling here lets us
    preserve that API while avoiding one TCP/session handshake per request.
    """

    def __init__(self) -> None:
        self._lock = threading.Condition()
        self._idle_by_target: dict[str, list[Any]] = {}
        self._total_by_target: dict[str, int] = {}

    def _pool_size(self) -> int:
        return _env_int("POSTGRES_POOL_MAX_SIZE", DEFAULT_POSTGRES_POOL_MAX_SIZE)

    def _pool_timeout(self) -> float:
        return _env_float("POSTGRES_POOL_TIMEOUT", DEFAULT_POSTGRES_POOL_TIMEOUT)

    def _create_connection(self, target: str) -> Any:
        return psycopg.connect(
            target,
            row_factory=dict_row,
            connect_timeout=10,
            prepare_threshold=None,
        )

    def acquire(self, target: str) -> Any:
        timeout = self._pool_timeout()
        max_size = self._pool_size()
        with self._lock:
            idle = self._idle_by_target.setdefault(target, [])
            total = self._total_by_target.get(target, 0)

            while True:
                while idle:
                    raw = idle.pop()
                    if self._is_connection_reusable(raw):
                        return raw
                    self._close_raw(raw)
                    total = max(0, self._total_by_target.get(target, 0) - 1)
                    self._total_by_target[target] = total

                if total < max_size:
                    self._total_by_target[target] = total + 1
                    break

                notified = self._lock.wait(timeout=timeout)
                idle = self._idle_by_target.setdefault(target, [])
                total = self._total_by_target.get(target, 0)
                if not notified and not idle and total >= max_size:
                    raise psycopg.OperationalError(
                        f"PostgreSQL connection pool exhausted for target={target!r}; "
                        f"max_size={max_size}"
                    )

        try:
            return self._create_connection(target)
        except Exception:
            with self._lock:
                current = self._total_by_target.get(target, 0)
                self._total_by_target[target] = max(0, current - 1)
                self._lock.notify()
            raise

    def release(self, target: str, raw: Any, *, discard: bool = False) -> None:
        if discard or not self._is_connection_reusable(raw):
            self._discard(target, raw)
            return

        self._reset_connection(raw)
        if not self._is_connection_reusable(raw):
            self._discard(target, raw)
            return

        with self._lock:
            self._idle_by_target.setdefault(target, []).append(raw)
            self._lock.notify()

    def _discard(self, target: str, raw: Any) -> None:
        self._close_raw(raw)
        with self._lock:
            current = self._total_by_target.get(target, 0)
            self._total_by_target[target] = max(0, current - 1)
            self._lock.notify()

    @staticmethod
    def _close_raw(raw: Any) -> None:
        try:
            raw.close()
        except Exception:
            pass

    @staticmethod
    def _is_connection_reusable(raw: Any) -> bool:
        return not bool(getattr(raw, "closed", False)) and not bool(getattr(raw, "broken", False))

    @staticmethod
    def _reset_connection(raw: Any) -> None:
        if not _PooledPostgresConnectionManager._is_connection_reusable(raw):
            return
        try:
            status = raw.pgconn.transaction_status
        except Exception:
            _PooledPostgresConnectionManager._close_raw(raw)
            return

        try:
            if status in {TransactionStatus.INERROR, TransactionStatus.INTRANS}:
                # Returning a connection to the pool must never make an
                # unfinished caller transaction durable.  Successful context
                # managers commit explicitly before close; anything left here
                # is leaked/abandoned work and must be rolled back.
                raw.rollback()
        except Exception:
            _PooledPostgresConnectionManager._close_raw(raw)


_POSTGRES_POOL = _PooledPostgresConnectionManager()


class ConnectionAdapter:
    """统一数据库连接接口，屏蔽 SQLite / PostgreSQL 差异。"""

    def __init__(self, raw: Any, engine: str, target: str, *, release_to_pool: bool = False):
        self._raw = raw
        self.engine = engine
        self.target = target
        self._release_to_pool = release_to_pool
        self._closed = False

    def __enter__(self) -> "ConnectionAdapter":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        close_discard = False
        try:
            if exc_type:
                self.rollback()
            else:
                self.commit()
        except Exception:
            close_discard = True
            raise
        finally:
            self.close(discard=close_discard)

    def _rewrite_sql(self, sql_text: str) -> str:
        if self.engine == "postgres":
            return qmark_to_format(sql_text)
        return sql_text

    def execute(self, sql_text: str, params: Any = None) -> CursorAdapter:
        cursor = self._raw.execute(self._rewrite_sql(sql_text), normalize_params(params))
        return CursorAdapter(cursor)

    def executemany(self, sql_text: str, seq_of_params: Iterable[Sequence[Any]]) -> CursorAdapter:
        if self.engine == "postgres":
            raw_cursor = self._raw.cursor()
            raw_cursor.executemany(
                self._rewrite_sql(sql_text),
                [normalize_params(item) for item in seq_of_params],
            )
        else:
            raw_cursor = self._raw.executemany(
                self._rewrite_sql(sql_text),
                [normalize_params(item) for item in seq_of_params],
            )
        return CursorAdapter(raw_cursor)

    def commit(self) -> None:
        if self._closed:
            return
        self._raw.commit()

    def rollback(self) -> None:
        if self._closed:
            return
        self._raw.rollback()

    def close(self, *, discard: bool = False) -> None:
        if self._closed:
            return
        self._closed = True
        if self._release_to_pool and self.engine == "postgres":
            _POSTGRES_POOL.release(self.target, self._raw, discard=discard)
            return
        self._raw.close()

    def table_exists(self, table_name: str, *, schema: str | None = None) -> bool:
        if self.engine == "postgres":
            table_schema = schema or "public"
            row = self.execute(
                """
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = ?
                  AND table_name = ?
                """,
                (table_schema, table_name),
            ).fetchone()
            return bool(row)

        row = self.execute(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?",
            (table_name,),
        ).fetchone()
        return bool(row)

    def table_columns(self, table_name: str, *, schema: str | None = None) -> tuple[str, ...]:
        if self.engine == "postgres":
            table_schema = schema or "public"
            rows = self.execute(
                """
                SELECT column_name
                FROM information_schema.columns
                WHERE table_schema = ?
                  AND table_name = ?
                ORDER BY ordinal_position
                """,
                (table_schema, table_name),
            ).fetchall()
            return tuple(str(row["column_name"]) for row in rows)

        rows = self.execute(f"PRAGMA table_info({quote_identifier(table_name)})").fetchall()
        return tuple(str(row[1]) for row in rows)

    def list_tables(self, prefix: str | None = None) -> list[str]:
        if self.engine == "postgres":
            sql_text = """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = current_schema()
            """
            params: list[Any] = []
            if prefix:
                sql_text += " AND table_name LIKE ?"
                params.append(f"{prefix}%")
            sql_text += " ORDER BY table_name"
            rows = self.execute(sql_text, params).fetchall()
            return [str(row["table_name"]) for row in rows]

        sql_text = """
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
              AND name NOT LIKE 'sqlite_%'
        """
        params: list[Any] = []
        if prefix:
            sql_text += " AND name LIKE ?"
            params.append(f"{prefix}%")
        sql_text += " ORDER BY name"
        rows = self.execute(sql_text, params).fetchall()
        return [str(row[0]) for row in rows]


def utc_now() -> str:
    """返回当前 UTC 时间的 ISO 8601 字符串。"""
    return datetime.now(timezone.utc).isoformat()


def connect(target: str | Path | None = None) -> ConnectionAdapter:
    """创建数据库连接。

    当 `target` 为空时，默认连接正式运行使用的 PostgreSQL。
    只有显式传入 SQLite 路径时，才启用 SQLite 兼容分支。
    """
    resolved = resolve_database_target(target)
    engine = detect_database_engine(resolved)

    if engine == "postgres":
        raw = _POSTGRES_POOL.acquire(resolved)
        return ConnectionAdapter(raw, engine, resolved, release_to_pool=True)

    db_path = Path(resolved)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    raw = sqlite3.connect(db_path)
    raw.row_factory = sqlite3.Row
    raw.execute("PRAGMA foreign_keys = ON")
    return ConnectionAdapter(raw, engine, str(db_path))
